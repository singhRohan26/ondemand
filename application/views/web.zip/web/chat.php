<section class="price_dscp topSpace boxs">
        <div class="container">
            <div class="price_box">
                <div class="row">
                    
                    
  <form method="post" action="<?php echo base_url('Web_users/chatInsert') ?>">
  <div class="form-group row">
   
    <div class="col-sm-10">
      <input type="text" class="form-control" id="inputEmail3" placeholder="" name="msg" required>
    </div>
  </div>
  
  
  
  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">send</button>
    </div>
  </div>
</form>
                </div>
            </div>
        </div>
    </section>