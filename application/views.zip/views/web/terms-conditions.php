<section class="terms_use topSpace boxs">
	<div class="container">
		<div class="term_content text-justify">
			<h3>Terms Of use</h3>
			<p><?php if(!empty($terms['content_description'])) { echo $terms['content_description']; } else { echo "No Record Found Here!"; }?></p>
		</div>
	</div>
</section>